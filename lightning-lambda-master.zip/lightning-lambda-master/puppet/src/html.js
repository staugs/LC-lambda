import middy from 'middy';
import chromium from 'chrome-aws-lambda';
import puppeteer from 'puppeteer-core';
import randomUA from 'modern-random-ua';
// eslint-disable-next-line no-unused-vars
import iltorb from 'iltorb';
import {
  cors,
  doNotWaitForEmptyEventLoop,
  httpHeaderNormalizer,
  httpErrorHandler,
} from 'middy/middlewares';
import { APIFY_PROXY_PASSWORD } from '../const';

const handler = async (event) => {
  const { url } = event.queryStringParameters;

  const executablePath = event.isOffline
    ? undefined
    : await chromium.executablePath;
  const browser = await puppeteer.launch({
    defaultViewport: chromium.defaultViewport,
    headless: chromium.headless,
    args: [
      ...chromium.args,
      '--proxy-server=http://proxy.apify.com:8000',
    ],
    dumpio: true,
    executablePath,
  });

  const page = await browser.newPage();
  await page.authenticate({
    // username: 'groups-BUYPROXIES94952',
    username: 'groups-RESIDENTIAL',
    password: APIFY_PROXY_PASSWORD,
  });
  await page.viewport({
    width: 1024 + Math.floor(Math.random() * 100),
    height: 768 + Math.floor(Math.random() * 100),
  });

  await page.setUserAgent(randomUA.generate());

  await page.goto(url, {
    waitUntil: ['networkidle0', 'load', 'domcontentloaded'],
  });
  await page.waitFor(5000);
  const content = await page.evaluate(() => document.body.innerHTML);

  return {
    statusCode: 200,
    body: JSON.stringify({
      content,
    }),
  };
};

export const scrape = middy(handler)
  .use(httpHeaderNormalizer())
  .use(cors())
  .use(doNotWaitForEmptyEventLoop())
  .use(httpErrorHandler());
