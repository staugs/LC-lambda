# lightning-lambda

Cron Trigger Scrapes of various data source. No front end, write direclty to DB. See `lighting-vis` repo for front end.

