/* eslint-disable no-underscore-dangle */
import { parse } from 'node-html-parser';
// import camelcase from 'camelcase';
import moment from 'moment-timezone';
import mongodb, { ObjectId } from 'mongodb';
import {
  MONGO_CLIENT_PARAMS,
  MONGO_DBNAME, MONGO_URL,
  BLOOMBERG_TO_TICKER,
  GS_PRODUCT_TO_SYMBOL,
} from '../config/const';

import apiCache from './helpers/apiCache';

export const test = async () => {
  const content = await apiCache({
    url: 'http://whatismyip.host/',
    // url: 'https://grayscale.co/bitcoin-trust/',
    // url: 'https://grayscale.co/zcash-trust/',
    // method: 'puppet',
    // method: 'apify',
    method: 'apifyResidential',
  });
  // eslint-disable-next-line no-console
  console.log(content);
};

const scrape = async (url) => {
  const ttl = 300;

  const client = await mongodb.MongoClient.connect(MONGO_URL, MONGO_CLIENT_PARAMS);
  const db = client.db(MONGO_DBNAME);
  const GRAYSCALE = db.collection('grayscale');
  let content = await apiCache({
    url,
    method: 'apify',
    ttl,
    mongoClient: client,
    // cache: false,
  });
  if (content === null || content === undefined || content.search(/Cloudflare Ray ID/) !== -1) {
    // eslint-disable-next-line no-console
    console.log('apify failed, tried apifyResidential');
    content = await apiCache({
      url,
      method: 'apifyResidential',
      ttl,
      mongoClient: client,
    });
  }
  if (content === null || content === undefined) {
    // eslint-disable-next-line no-console
    console.log('scrape failed');
    await client.close();
    return false;
  }
  if (content.search(/Cloudflare Ray ID/) !== -1) {
    // eslint-disable-next-line no-console
    console.log('cloudflare blocked');
    await client.close();
    return false;
  }
  // console.log(parse(content).querySelectorAll('.label-mobile'));
  const keysToStore = {
    AUM: 'aum',
    'Shares Outstanding': 'sharesOutstanding',
    'Token per Share': 'cryptoPerShare',
    Bloomberg: 'symbol',
  };
  const overview = {};
  parse(content).querySelectorAll('.label-mobile').forEach((label) => {
    const dataTitle = label.getAttribute('data-title');
    if (keysToStore[dataTitle] !== undefined) {
      // console.log(dataTitle);
      // console.log(label.childNodes.toString().replace(/[^01-9.]+/g, ''));
      const key = keysToStore[dataTitle];
      switch (key) {
        case 'symbol':
          overview[key] = label.childNodes.toString();
          if (BLOOMBERG_TO_TICKER[overview[key]] !== undefined) {
            overview[key] = BLOOMBERG_TO_TICKER[overview[key]];
          }
          break;
        default:
          overview[keysToStore[dataTitle]] = label.childNodes.toString().replace(/[^01-9.]+/g, '');
      }
    }
  });

  let dateString = '';
  parse(content).querySelectorAll('.jet-listing-dynamic-field__content').forEach((element) => {
    const elementString = element.childNodes.toString();
    if (elementString.match(/Returns \(At close as of/)) {
      dateString = element.childNodes.toString().replace(/[^01-9/]/g, '');
    }
  });
  let cryptoPerShare = null;
  if (overview.symbol === 'GDLC') {
    const cryptoPerShareObj = {};
    parse(content).querySelectorAll('sup').forEach((element) => {
      const strong = element.querySelector('strong');
      if (strong !== null && strong.childNodes.toString().match(/^(?!Fund)/)) {
        const label = element.childNodes[0].childNodes.toString();
        const value = element.childNodes[1].toString().replace(/[^01-9.]+/g, '');
        cryptoPerShareObj[label] = parseFloat(value);
      }
    });
    // console.log(cryptoPerShareObj);
    cryptoPerShare = Object.keys(cryptoPerShareObj).map((key) => ({
      name: key,
      value: cryptoPerShareObj[key],
    }));
    // console.log(cryptoPerShare);
  }

  const newRow = {
    symbol: overview.symbol,
    aum: parseFloat(overview.aum),
    sharesOutstanding: parseInt(overview.sharesOutstanding, 10),
    cryptoPerShare: cryptoPerShare !== null ? cryptoPerShare : parseFloat(overview.cryptoPerShare),
    dateString,
    dateStamp: moment.tz(`${dateString} 16:00`, 'MM/DD/YYYY HH:mm', 'America/New_York').unix(),
    // priceMarket: parseFloat(priceMarket),
    // priceNAV: parseFloat(priceNAV),
  };
  // console.log(overview);
  // console.log(newRow);
  await GRAYSCALE.updateOne(
    {
      symbol: newRow.symbol,
      dateString: newRow.dateString,
    },
    {
      $set: newRow,
    },
    { upsert: true },
  );

  // -- Find entries with missing price data
  const entriesToFill = await GRAYSCALE.find({
    symbol: newRow.symbol,
    $or: [
      { priceMarket: { $exists: false } },
      { priceNAV: { $exists: false } },
    ],
  }).toArray();
  // console.log(entriesToFill);

  // -- Get Data for Chart
  const chartData = {};
  parse(content).querySelectorAll('script').forEach((row) => {
    if (row.toString().match(/chart_data/) !== null) {
      const lines = row.childNodes.toString().split(';');
      // console.log(lines);
      lines.forEach((line) => {
        const lineArray = line.split('=');
        if (lineArray[0].match(/chart_data/) !== null) {
          // console.log(lineArray[0]);
          const json = JSON.parse(lineArray[1]);
          json.Holding.forEach((dayRow) => {
            const dateStringRow = moment(dayRow.x).utc().format('MM/DD/YYYY');
            const price = parseFloat(dayRow.y);
            // console.log(dateStringRow);
            // console.log(price);
            if (chartData[dateStringRow] === undefined) chartData[dateStringRow] = {};
            chartData[dateStringRow].priceNAV = price;
          });
          json.Benchmark.forEach((dayRow) => {
            const dateStringRow = moment(dayRow.x).utc().format('MM/DD/YYYY');
            const price = parseFloat(dayRow.y);
            if (chartData[dateStringRow] === undefined) chartData[dateStringRow] = {};
            chartData[dateStringRow].priceMarket = price;
          });
          // console.log(JSON.parse(lineArray[1]));
        }
      });
      // console.log(row.childNodes.toString());
    }
  });
  // console.log(chartData);

  // -- Prepare rows to save
  const entriesToPatch = [];
  entriesToFill.forEach((missingDataRow) => {
    // console.log(missingDataRow.dateString);
    if (chartData[missingDataRow.dateString] !== undefined) {
      entriesToPatch.push({
        _id: missingDataRow._id,
        dateString: missingDataRow.dateString,
        symbol: missingDataRow.symbol,
        priceNAV: chartData[missingDataRow.dateString].priceNAV,
        priceMarket: chartData[missingDataRow.dateString].priceMarket,
      });
    }
  });
  // console.log(entriesToPatch);
  await Promise.all(entriesToPatch.map(async (row) => {
    await GRAYSCALE.updateOne(
      {
        _id: new ObjectId(row._id),
      },
      {
        $set: {
          priceMarket: row.priceMarket,
          priceNAV: row.priceNAV,
        },
      },
    );
    // console.log(row);
  }));

  await client.close();
  return false;
};

export const GBTC = async () => {
  await scrape('https://grayscale.co/bitcoin-trust/');
  return {
    statusCode: 200,
    body: JSON.stringify({
      message: 'GBTC Scrape',
    }),
  };
};
export const BCHG = async () => {
  await scrape('https://grayscale.co/bitcoin-cash-trust/');
  return {
    statusCode: 200,
    body: JSON.stringify({
      message: 'BCHG Scrape',
    }),
  };
};
export const ETHE = async () => {
  await scrape('https://grayscale.co/ethereum-trust/');
  return {
    statusCode: 200,
    body: JSON.stringify({
      message: 'ETHE Scrape',
    }),
  };
};
export const ETCG = async () => {
  await scrape('https://grayscale.co/ethereum-classic-trust/');
  return {
    statusCode: 200,
    body: JSON.stringify({
      message: 'ETCG Scrape',
    }),
  };
};
export const ZEN = async () => {
  await scrape('https://grayscale.co/horizen-trust/');
  return {
    statusCode: 200,
    body: JSON.stringify({
      message: 'ZEN Scrape',
    }),
  };
};
export const LTCN = async () => {
  await scrape('https://grayscale.co/litecoin-trust/');
  return {
    statusCode: 200,
    body: JSON.stringify({
      message: 'LTCN Scrape',
    }),
  };
};
export const XLM = async () => {
  await scrape('https://grayscale.co/stellar-lumens-trust/');
  return {
    statusCode: 200,
    body: JSON.stringify({
      message: 'XLM Scrape',
    }),
  };
};
export const ZEC = async () => {
  await scrape('https://grayscale.co/zcash-trust/');
  return {
    statusCode: 200,
    body: JSON.stringify({
      message: 'ZEC Scrape',
    }),
  };
};
export const GDLC = async () => {
  await scrape('https://grayscale.co/digital-large-cap/');
  return {
    statusCode: 200,
    body: JSON.stringify({
      message: 'GDLC Scrape',
    }),
  };
};
export const BAT = async () => {
  await scrape('https://grayscale.co/basic-attention-token-trust/');
  return {
    statusCode: 200,
    body: JSON.stringify({
      message: 'BAT Scrape',
    }),
  };
};
export const LINK = async () => {
  await scrape('https://grayscale.co/chainlink-trust/');
  return {
    statusCode: 200,
    body: JSON.stringify({
      message: 'LINK Scrape',
    }),
  };
};
export const MANA = async () => {
  await scrape('https://grayscale.co/decentraland-trust/');
  return {
    statusCode: 200,
    body: JSON.stringify({
      message: 'MANA Scrape',
    }),
  };
};
export const FIL = async () => {
  await scrape('https://grayscale.co/filecoin-trust/');
  return {
    statusCode: 200,
    body: JSON.stringify({
      message: 'FIL Scrape',
    }),
  };
};
export const LPT = async () => {
  await scrape('https://grayscale.co/livepeer-trust/');
  return {
    statusCode: 200,
    body: JSON.stringify({
      message: 'LPT Scrape',
    }),
  };
};

export const GAAP = async () => {
  const client = await mongodb.MongoClient.connect(MONGO_URL, MONGO_CLIENT_PARAMS);
  const db = client.db(MONGO_DBNAME);
  const GRAYSCALE = db.collection('grayscale');
  const url = 'https://grayscale.com/gaap-page/';
  const ttl = 60;
  const content = await apiCache({
    url,
    method: 'apify',
    ttl,
    mongoClient: client,
    cache: false,
  });
  // console.log(content);
  let dateString = '';
  parse(content).querySelectorAll('.elementor-text-editor.elementor-clearfix sup').forEach((element) => {
    if (element.childNodes.toString().match(/^\^ At close as of/)) {
      dateString = element.childNodes.toString().replace(/^\^ At close as of/, '').trim();
      dateString = moment(dateString, 'MMMM DD, YYYY').format('MM/DD/YYYY');
    }
  });

  const rowsToSave = [];
  Object.keys(GS_PRODUCT_TO_SYMBOL).forEach((product) => {
    parse(content).querySelectorAll('.elementor-row .elementor-row .elementor-row').forEach((element) => {
      const elementString = element.childNodes.toString();
      const reg = new RegExp(product);
      if (elementString.match(reg)) {
        const newRow = {
          symbol: GS_PRODUCT_TO_SYMBOL[product],
          dateString,
          dateStamp: moment.tz(`${dateString} 16:00`, 'MM/DD/YYYY HH:mm', 'America/New_York').unix(),
        };
        const info = element.querySelectorAll('.jet-listing-dynamic-field__content').map((cell) => (
          cell.childNodes.toString()
        ));
        const priceNAV = info[2].replace(/[^01-9.]+/g, '');
        const priceMarket = info[4].replace(/[^01-9.]+/g, '');
        newRow.priceNAV = priceNAV === '' ? 0 : parseFloat(priceNAV);
        newRow.priceMarket = priceMarket === '' ? 0 : parseFloat(priceMarket);
        // console.log(newRow);
        rowsToSave.push(newRow);
      }
    });
  });
  // console.log(rowsToSave);
  await Promise.all(rowsToSave.map(async (newRow) => {
    // console.log(newRow);
    await GRAYSCALE.updateOne(
      {
        symbol: newRow.symbol,
        dateString: newRow.dateString,
      },
      {
        $set: newRow,
      },
      { upsert: true },
    );
  }));

  await client.close();
  return {
    statusCode: 200,
    body: JSON.stringify({
      message: 'GAAP',
    }),
  };
};
