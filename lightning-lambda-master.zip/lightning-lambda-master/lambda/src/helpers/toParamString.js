export default (params) => Object.keys(params).map(((propName) => (`${propName}=${params[propName]}`))).join('&');
