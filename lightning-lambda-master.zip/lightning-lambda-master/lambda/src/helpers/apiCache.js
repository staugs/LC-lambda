import fetch from 'node-fetch';
import mongodb from 'mongodb';
import moment from 'moment';

import {
  APIFY_TOKEN,
  MONGO_CLIENT_PARAMS,
  MONGO_DBNAME,
  MONGO_URL,
  SERVERLESS_PUPPET_KEY,
} from '../../config/const';

const apiCache = async ({
  url = 'https://google.com',
  method = 'getHtml',
  ttl = 60, // in mintues
  mongoClient,
  cache = true,
}) => {
  let res;
  let body;
  let json;
  let client = mongoClient;
  const cacheKey = {
    url,
    // method,
  };

  if (mongoClient === undefined) {
    client = await mongodb.MongoClient.connect(MONGO_URL, MONGO_CLIENT_PARAMS);
  }
  const db = client.db(MONGO_DBNAME);
  const APICACHE = db.collection('apiCache');
  const cacheRow = await APICACHE.findOne({
    ttl: {
      $gt: moment().unix() - (ttl * 60),
    },
    ...cacheKey,
  });
  if (cache && cacheRow !== null && cacheRow.body !== undefined) {
    console.log('has cache');
    body = cacheRow.body;
  } else {
    console.log(`get live using ${method}`);
    switch (method) {
      case 'puppet':
        res = await fetch(`https://0giamytu5m.execute-api.us-east-1.amazonaws.com/pro/html/scrape?url=${url}`, {
          method: 'post',
          body: '',
          headers: { 'x-api-key': SERVERLESS_PUPPET_KEY },
        });
        json = await res.json();
        // console.log(json);
        body = json.content;
        break;
      case 'apify':
        res = await fetch(`https://api.apify.com/v2/acts/SL2AceuKvCHxIPVA1/run-sync?token=${APIFY_TOKEN}`, {
          method: 'post',
          body: JSON.stringify({
            url,
            'x-api-key': '1Xv1761M89oQzrcaukG0NScYQSsBSUdGa128OMZ0hmuUrSL6e6',
          }),
          headers: { 'Content-Type': 'application/json' },
        });
        json = await res.json();
        // console.log(json);
        body = json.content;
        break;
      case 'apifyResidential':
        res = await fetch(`https://api.apify.com/v2/acts/WQnMmlVjXqUf3U07a/run-sync?token=${APIFY_TOKEN}`, {
          method: 'post',
          body: JSON.stringify({
            url,
            'x-api-key': '1Xv1761M89oQzrcaukG0NScYQSsBSUdGa128OMZ0hmuUrSL6e6',
          }),
          headers: { 'Content-Type': 'application/json' },
        });
        json = await res.json();
        // console.log(json);
        body = json.content;
        break;
      case 'getHtml':
        res = await fetch(url, {
          headers: {
            'User-Agent': 'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:85.0) Gecko/20100101 Firefox/85.0',
          },
        });
        body = await res.text();
        break;
      default:
        console.log(method);
    }
    // console.log(body);
    if (
      body !== undefined
      && body !== null
      && body.search(/Cloudflare Ray ID/) !== -1
    ) {
      console.log('cloudflare block');
      body = null;
    }
    if (
      body !== undefined
      && body !== null
      && body.search(/403 Forbidden/) !== -1
    ) {
      console.log('403 Forbidden');
      body = null;
    }

    if (body && body !== null) {
      const newRow = {
        ttl: moment().unix(),
        body,
        ...cacheKey,
      };
      await APICACHE.updateOne(
        cacheKey,
        {
          $set: newRow,
        },
        { upsert: true },
      );
    }
  }

  if (mongoClient === undefined) await client.close();
  // console.log(body);
  return body;
};
export default apiCache;
