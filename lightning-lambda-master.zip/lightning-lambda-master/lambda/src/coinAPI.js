import fetch from 'node-fetch';
import fs from 'fs';
import mongodb from 'mongodb';
import moment from 'moment';

import {
  MONGO_URL, MONGO_DBNAME,
  CA_BASE_URL, CA_API_KEY, RETURN_HEADER_CORS, PERIOD_1DAY, MONGO_CLIENT_PARAMS,
} from '../config/const';

// eslint-disable-next-line import/prefer-default-export
export const scrapeAssets = async () => {
  const CACHE = false;
  const cacheFile = '../../src/cache/assets.json';
  let json = [];
  if (CACHE) {
    json = await new Promise((resolve) => {
      fs.readFile(cacheFile, 'utf8', (err, data) => {
        if (err) return console.error(err);
        resolve(JSON.parse(data));
        return 1;
      });
    });
  } else {
    const url = `${CA_BASE_URL}/assets`;
    const res = await fetch(url, {
      headers: {
        'X-CoinAPI-Key': CA_API_KEY,
      },
    });
    json = await res.json();
    fs.writeFile(cacheFile, JSON.stringify(json, null, 4), (err) => {
      if (err) return console.error(err);
      return 1;
    });
  }
  // console.log(json);
  const uri = MONGO_URL;
  const client = await mongodb.MongoClient.connect(uri, MONGO_CLIENT_PARAMS);
  const db = client.db(MONGO_DBNAME);
  const Assets = db.collection('coinApiAssets');
  await Promise.all(json.map(async (row) => {
    await Assets.updateOne(
      {
        asset_id: row.asset_id,
      },
      { $set: row },
      { upsert: true },
    );
  }));
  await client.close();
  return {
    statusCode: 200,
    body: JSON.stringify({
      message: 'scrapeAssets',
    }),
  };
};

async function getLatestOHLCVDate(period, coin, OHLCV) {
  // console.log({ period, coin, OHLCV });
  const latestRow = await OHLCV.findOne({ period, coin }, { sort: { timePeriodStart: -1 } });
  // console.log(latestRow);
  if (latestRow === null) return null;
  return (latestRow.time_period_start);
}
async function getOldestOHLCVDate(period, coin, OHLCV) {
  // console.log({ period, coin, OHLCV });
  const latestRow = await OHLCV.findOne({ period, coin }, { sort: { timePeriodStart: 1 } });
  // console.log(latestRow);
  if (latestRow === null) return null;
  return (latestRow.time_period_start);
}

async function getTrackedCoins(client) {
  const db = client.db(MONGO_DBNAME);
  const Assets = db.collection('coinApiAssets');
  const coins = await Assets.find({ track: true }).toArray();
  return coins;
}

async function scrapOHLCVCoin({ coin, client, timeStart }) {
  // console.log(coin);
  const CACHE = false;
  const WRITECACHE = false;

  const db = client.db(MONGO_DBNAME);
  const OHLCV = db.collection('coinApiOHLCV');

  const period = PERIOD_1DAY;
  const limit = '366';
  let timeStartPatched = timeStart;
  if (timeStartPatched === undefined) {
    timeStartPatched = moment.utc(moment().format('YYYY-MM-DD')).subtract(366, 'days').toISOString();
  }
  // console.log(timeStartPatched);
  const url = `${CA_BASE_URL}/ohlcv/${coin}/USD/history?period_id=${period}&time_start=${timeStartPatched}&limit=${limit}`;
  const cacheFile = `../../src/cache/ohlcv-${coin}-${period}-${moment(timeStartPatched).unix()}-${limit}.json`;
  let json = [];
  if (CACHE) {
    json = await new Promise((resolve) => {
      fs.readFile(cacheFile, 'utf8', (err, data) => {
        if (err) return console.error(err);
        resolve(JSON.parse(data));
        return 1;
      });
    });
  } else {
    const res = await fetch(url, {
      headers: {
        'X-CoinAPI-Key': CA_API_KEY,
      },
    });
    // console.log(res);
    json = await res.json();
    if (WRITECACHE) {
      fs.writeFile(cacheFile, JSON.stringify(json, null, 4), (err) => {
        if (err) return console.error(err);
        return 1;
      });
    }
  }
  await Promise.all(json.map(async (row) => {
    const rowPatched = { ...row };
    rowPatched.timePeriodStart = moment(row.time_period_start).unix();
    rowPatched.timePeriodEnd = moment(row.time_period_end).unix();
    rowPatched.coin = coin;
    rowPatched.period = period;
    await OHLCV.updateOne(
      {
        period: rowPatched.period,
        coin: rowPatched.coin,
        timePeriodStart: rowPatched.timePeriodStart,
      },
      { $set: rowPatched },
      { upsert: true },
    );
  }));
}

export const scrapOHLCV = async () => {
  const uri = MONGO_URL;
  const client = await mongodb.MongoClient.connect(uri, MONGO_CLIENT_PARAMS);
  const trackedCoins = await getTrackedCoins(client);
  await Promise.all(trackedCoins.map(async (row, index) => {
    await new Promise((resovle) => setTimeout(resovle, index * 1000));
    const period = PERIOD_1DAY;
    const coin = row.asset_id;
    const db = client.db(MONGO_DBNAME);
    const OHLCV = db.collection('coinApiOHLCV');
    let timeStart = await getLatestOHLCVDate(period, coin, OHLCV);
    if (timeStart === null) {
      timeStart = moment.utc(moment().format('YYYY-MM-DD')).subtract(366, 'days').toISOString();
    }
    console.log(`${coin} ${timeStart}`);
    await scrapOHLCVCoin({
      coin,
      client,
      timeStart,
    });
  }));
  await client.close();
  return {
    statusCode: 200,
    headers: RETURN_HEADER_CORS,
    body: JSON.stringify({
      message: 'scrapOHLCV',
    }),
  };
};

export const backFillOHLCV = async () => {
  const backDateLimit = '2017-01-01';
  const uri = MONGO_URL;
  const client = await mongodb.MongoClient.connect(uri, MONGO_CLIENT_PARAMS);
  const trackedCoins = await getTrackedCoins(client);
  await Promise.all(trackedCoins.map(async (row, index) => {
    await new Promise((resovle) => setTimeout(resovle, index * 1000));
    const period = PERIOD_1DAY;
    const coin = row.asset_id;
    const db = client.db(MONGO_DBNAME);
    const OHLCV = db.collection('coinApiOHLCV');
    let oldestDate = await getOldestOHLCVDate(period, coin, OHLCV);
    if (oldestDate === null) {
      oldestDate = moment.utc(moment().format('YYYY-MM-DD')).toISOString();
    }
    console.log(`${moment.utc(oldestDate).format('YYYY-MM-DD')} (${coin} oldest)`);
    let timeStart = moment.utc(oldestDate).subtract(360, 'days').toISOString();
    if (moment.utc(backDateLimit).unix() > moment.utc(timeStart).unix()) {
      timeStart = moment.utc(backDateLimit).toISOString();
    }
    // console.log(`${moment.utc(timeStart).format('YYYY-MM-DD')} (${coin} start)`);

    await scrapOHLCVCoin({
      coin,
      client,
      timeStart,
    });
  }));
  await client.close();
  return {
    statusCode: 200,
    headers: RETURN_HEADER_CORS,
    body: JSON.stringify({
      message: 'scrapOHLCV',
    }),
  };
};
