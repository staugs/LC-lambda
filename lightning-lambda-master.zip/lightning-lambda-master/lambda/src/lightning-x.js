/* eslint-disable no-use-before-define */
import fetch from 'node-fetch';
import moment from 'moment';
import mongodb from 'mongodb';
import fs from 'fs';

import {
  MONGO_URL, MONGO_DBNAME, LEDGERX_BASEURL,
  LEDGERX_API_BASEURL, MONGO_CLIENT_PARAMS, LX_TRADE_DBNAME,
  LX_BEFORE_TS, LX_AFTER_TS,
} from '../config/const';
import toParamString from './helpers/toParamString';

async function getLedgerXApiKey() {
  const client = await mongodb.MongoClient.connect(MONGO_URL, MONGO_CLIENT_PARAMS);
  const db = client.db(MONGO_DBNAME);
  const Settings = db.collection('settings');
  const setting = await Settings.findOne({ name: 'LedgerX API Key' });
  await client.close();
  return setting.value;
}

const todayURL = (dateString) => {
  let url = LEDGERX_BASEURL;
  if (dateString === undefined) {
    url = `${url}${moment().subtract(1, 'day').format('YYYY-MM-DD')}.json`;
  } else {
    url = `${url}${dateString}.json`;
  }
  return url;
};

export const processScrapedData = async (data, paramClient) => {
  // console.log(paramClient);
  let client = paramClient;
  if (paramClient === undefined) {
    client = await mongodb.MongoClient.connect(MONGO_URL, MONGO_CLIENT_PARAMS);
  }

  const db = client.db(MONGO_DBNAME);
  const Daily = db.collection('dailys');
  const Contract = db.collection('contracts');

  await Promise.all(data.report_data.map(async (row) => {
    const label = row.contract_label.split(' ');
    let coin;
    let date;
    let type;
    let amount;
    switch (row.contract_type) {
      case 'options_contract':
        [coin, date, type, amount] = label;
        break;
      case 'future_contract':
        [date, type, coin] = label;
        break;
      case 'day_ahead_swap':
        break;
      default:
        console.log(`Unknown contract type: ${row.contract_type}`);
    }
    if (coin === 'cBTC' && (row.contract_type === 'options_contract' || row.contract_type === 'future_contract')) {
      const newRow = row;
      newRow.contractDate = moment(date).unix();
      newRow.contractDateString = date;
      newRow.reportDateString = data.date;
      newRow.reportDate = moment(data.date, 'YYYY-MM-DD HH:mm:ss ZZ').unix();
      newRow.type = type;
      newRow.coin = coin;
      if (amount !== undefined) {
        newRow.amount = Number(amount.replace('$', '').replace(',', ''));
      }
      const contractRow = {
        contract_label: row.contract_label,
        contractDate: newRow.contractDate,
        contractDateString: newRow.contractDateString,
        coin: newRow.coin,
        type: newRow.type,
        amount: newRow.amount,
      };
      // console.log(newRow);
      await Daily.updateOne(
        {
          contract_id: newRow.contract_id,
          reportDate: newRow.reportDate,
        },
        { $set: newRow },
        { upsert: true },
      );
      await Contract.updateOne(
        {
          contract_label: contractRow.contract_label,
        },
        { $set: contractRow },
        { upsert: true },
      );
    }
  }));
  if (paramClient === undefined) await client.close();
};

export const scrapeToday = async () => {
  const CACHE = false;
  const cacheFile = '../../src/cache/scrapeToday.json';
  let json = [];
  if (CACHE) {
    json = await new Promise((resolve) => {
      fs.readFile(cacheFile, 'utf8', (err, data) => {
        if (err) return console.error(err);
        resolve(JSON.parse(data));
        return 1;
      });
    });
  } else {
    const url = todayURL();
    const res = await fetch(url);
    json = await res.json();
    fs.writeFile(cacheFile, JSON.stringify(json, null, 4), (err) => {
      if (err) return console.error(err);
      return 1;
    });
  }
  // console.log(json);
  await processScrapedData(json);
  return {
    statusCode: 200,
    body: JSON.stringify({
      message: 'scrapeToday',
    }),
  };
};

export const backFill = async () => {
  const numberOfDays = 30;
  const numberOfDaysArray = [];
  for (let i = 1; i <= numberOfDays; i += 1) {
    numberOfDaysArray.push(i);
  }
  const client = await mongodb.MongoClient.connect(MONGO_URL, MONGO_CLIENT_PARAMS);
  await Promise.all(numberOfDaysArray.map(async (i) => {
    const url = todayURL(moment().subtract(i, 'days').format('YYYY-MM-DD'));
    const res = await fetch(url);
    const json = await res.json();
    await processScrapedData(json, client);
  }));
  await client.close();
  return {
    statusCode: 200,
    body: JSON.stringify({
      message: 'backFill',
    }),
  };
};

export const allTradeFill = async () => {
  let offset = 0;
  const limit = 200;

  // load DB
  const client = await mongodb.MongoClient.connect(MONGO_URL, MONGO_CLIENT_PARAMS);
  const db = client.db(MONGO_DBNAME);

  // find newest
  const lxTrades = db.collection(LX_TRADE_DBNAME);
  const newestTrade = await lxTrades.findOne({}, { sort: { timestamp: -1 } });
  const afterTS = moment.unix(Math.floor(newestTrade.timestamp / 1000000000));

  // get first page
  const result = await getAllTrade(offset, limit, afterTS, LX_AFTER_TS);
  await saveAllTrade(result.data, client);

  // loop through rest of the pages
  const totalEntries = result.meta.total_count;
  const pages = Math.floor(totalEntries / limit);
  if (pages > 0) {
    const countArray = [];
    for (let i = 1; i <= pages; i += 1) {
      countArray.push(i * 2);
    }
    await Promise.all(countArray.map(async (index) => {
      await new Promise((resovle) => setTimeout(resovle, index * 1000));
      offset += limit;
      if (offset < totalEntries) {
        const resultMore = await getAllTrade(offset, limit, afterTS, LX_AFTER_TS);
        await saveAllTrade(resultMore.data, client);
      }
    }));
  }

  // close DB
  await client.close();
  return {
    statusCode: 200,
    body: JSON.stringify({
      message: 'get latest trades',
    }),
  };
};

export const allTradeBackFlll = async () => {
  let offset = 0;
  const limit = 200;

  // find oldest
  const client = await mongodb.MongoClient.connect(MONGO_URL, MONGO_CLIENT_PARAMS);
  const db = client.db(MONGO_DBNAME);
  const lxTrades = db.collection(LX_TRADE_DBNAME);
  const oldestTrade = await lxTrades.findOne({}, { sort: { timestamp: 1 } });
  const beforeTS = moment.unix(Math.ceil(oldestTrade.timestamp / 1000000000));

  // get first page
  const result = await getAllTrade(offset, limit, beforeTS, LX_BEFORE_TS);
  await saveAllTrade(result.data, client);

  // loop through more pages
  const totalEntries = result.meta.total_count;
  const pages = Math.floor(totalEntries / limit);
  const countArray = [];
  for (let i = 1; i <= 20 && i <= pages; i += 1) {
    countArray.push(i * 2);
  }
  await Promise.all(countArray.map(async (index) => {
    await new Promise((resovle) => setTimeout(resovle, index * 1000));
    offset += limit;
    if (offset < totalEntries) {
      const resultMore = await getAllTrade(offset, limit, beforeTS, LX_BEFORE_TS);
      await saveAllTrade(resultMore.data, client);
    }
  }));
  await client.close();
  return {
    statusCode: 200,
    body: JSON.stringify({
      message: 'backFill',
    }),
  };
};

const getAllTrade = async (offset, limit, timestamp, mode) => {
  console.log({ offset, limit });
  const CACHE = false;
  const WRITECACHE = false;

  const url = `${LEDGERX_API_BASEURL}/trades/global`;
  const cacheFile = `../../src/cache/ledger-x-trade-global-${mode}-${timestamp.unix()}-${offset}-${limit}.json`;
  const TimestampISO = timestamp.toISOString();

  let json = [];
  if (CACHE) {
    json = await new Promise((resolve) => {
      fs.readFile(cacheFile, 'utf8', (err, data) => {
        if (err) return console.error(err);
        resolve(JSON.parse(data));
        return 1;
      });
    });
  } else {
    const params = {
      limit,
      offset,
      [mode]: TimestampISO,
    };
    const LEDGERX_API_KEY = await getLedgerXApiKey();
    // console.log(LEDGERX_API_KEY);
    const res = await fetch(`${url}?${toParamString(params)}`, {
      headers: {
        Authorization: `JWT ${LEDGERX_API_KEY}`,
        'Content-Type': 'application/json',
      },
    });
    // console.log(res);
    json = await res.json();
    if (WRITECACHE) {
      fs.writeFile(cacheFile, JSON.stringify(json, null, 4), (err) => {
        if (err) return console.error(err);
        return 1;
      });
    }
  }
  return json;
};

const saveAllTrade = async (data, paramClient) => {
  let client = paramClient;
  if (paramClient === undefined) {
    client = await mongodb.MongoClient.connect(MONGO_URL, MONGO_CLIENT_PARAMS);
  }
  const db = client.db(MONGO_DBNAME);
  const lxTrades = db.collection(LX_TRADE_DBNAME);
  await Promise.all(data.map(async (row) => {
    await lxTrades.updateOne(
      {
        id: row.id,
      },
      { $set: row },
      { upsert: true },
    );
  }));
  if (paramClient === undefined) await client.close();
};
