/* eslint-disable no-underscore-dangle */
import mongodb, { ObjectId } from 'mongodb';
import moment from 'moment-timezone';
import csvtojson from 'csvtojson';

import {
  MONGO_URL, MONGO_DBNAME,
  MONGO_CLIENT_PARAMS, BLOOMBERG_TO_TICKER,
} from '../config/const';

import apiCache from './helpers/apiCache';

const scrapeOneCoin = async ({
  entries,
  symbol,
  client,
  Grayscale,
}) => {
  const ttl = 300;
  // console.log({ entries, symbol });
  entries.sort((a, b) => {
    if (a.dateStamp > b.dateStamp) return 1;
    if (a.dateStamp < b.dateStamp) return -1;
    return 0;
  });
  // console.log(entries);
  const startTime = moment.tz(`${entries[0].dateString} 12:01`, 'MM/DD/YYYY HH:mm', 'America/New_York').unix(); // 1587956962;
  const lastEntry = entries[entries.length - 1];
  const endTime = moment.tz(`${lastEntry.dateString} 18:00`, 'MM/DD/YYYY HH:mm', 'America/New_York').unix(); // 1587956962;
  // console.log({ startTime, endTime });
  const yahooURL = `https://query1.finance.yahoo.com/v7/finance/download/${symbol}?period1=${startTime}&period2=${endTime}&interval=1d&events=history&includeAdjustedClose=true`;
  const content = await apiCache({
    url: yahooURL,
    method: 'getHtml',
    ttl,
    mongoClient: client,
  });
  console.log(symbol);
  // console.log(content);
  const contentJson = await csvtojson().fromString(content);
  // console.log(contentJson);
  const entriesToSave = [];
  entries.forEach((row) => {
    // const dateString = moment(row.dateString, 'MM/DD/YYYY').format('YYYY-MM-DD');
    contentJson.forEach((yahooRow) => {
      const yahooDateString = moment(yahooRow.Date, 'YYYY-MM-DD').format('MM/DD/YYYY');
      if (yahooDateString === row.dateString) {
        // console.log({ yahooRow, row });
        entriesToSave.push({
          _id: row._id,
          symbol: row.symbol,
          dateString: row.dateString,
          priceMarket: parseFloat(yahooRow.Close),
        });
      }
    });
  });
  await Promise.all(entriesToSave.map(async (row) => {
    await Grayscale.updateOne(
      {
        _id: new ObjectId(row._id),
      },
      {
        $set: {
          priceMarket: row.priceMarket,
        },
      },
    );
    console.log(row);
  }));
};

export const scrapeMarketPrice = async () => {
  const client = await mongodb.MongoClient.connect(MONGO_URL, MONGO_CLIENT_PARAMS);
  const db = client.db(MONGO_DBNAME);
  const Grayscale = db.collection('grayscale');
  const symbols = Object.keys(BLOOMBERG_TO_TICKER).map((key) => (BLOOMBERG_TO_TICKER[key]));
  const entriesToFill = await Grayscale.find({
    symbol: { $in: symbols },
    priceMarket: { $exists: false },
  }).toArray();
  const entriesBySymbols = {};
  entriesToFill.forEach((row) => {
    if (entriesBySymbols[row.symbol] === undefined) entriesBySymbols[row.symbol] = [];
    entriesBySymbols[row.symbol].push(row);
  });
  // console.log(entriesBySymbols);
  await Promise.all(Object.keys(entriesBySymbols).map(async (symbol) => {
    await scrapeOneCoin({
      symbol,
      entries: entriesBySymbols[symbol],
      client,
      Grayscale,
    });
  }));
  await client.close();
  return {
    statusCode: 200,
    body: JSON.stringify({
      message: 'scrapeToday',
    }),
  };
};
