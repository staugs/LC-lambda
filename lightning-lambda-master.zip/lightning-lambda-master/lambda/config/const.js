export const {
  CA_API_KEY,
  MONGO_URL,
  APIFY_TOKEN,
  SERVERLESS_PUPPET_KEY,
} = process.env;

export const MONGO_DBNAME = 'lightningx';
export const MONGO_CLIENT_PARAMS = {
  useNewUrlParser: true,
  useUnifiedTopology: true,
};

export const LEDGERX_BASEURL = 'https://s3.amazonaws.com/data.ledgerx.com/json/';
export const LEDGERX_API_BASEURL = 'https://trade.ledgerx.com/api';

export const CA_BASE_URL = 'https://rest.coinapi.io/v1';

export const RETURN_HEADER_CORS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Credentials': true,
};

export const PERIOD_1DAY = '1DAY';

export const LX_TRADE_DBNAME = 'lxTrades';
export const LX_BEFORE_TS = 'before_ts';
export const LX_AFTER_TS = 'after_ts';

export const BLOOMBERG_TO_TICKER = {
  'GBTC US': 'GBTC',
  'ETHE US': 'ETHE',
  'ETCG US': 'ETCG',
  DLCFUND: 'GDLC',
  BCHFUND: 'BCHG',
  LTCFUND: 'LTCN',
};

export const GS_PRODUCT_TO_SYMBOL = {
  'Grayscale® Basic Attention Token Trust': 'BATFUND',
  'Grayscale® Bitcoin Trust': 'GBTC',
  'Grayscale® Bitcoin Cash Trust': 'BCHG',
  'Grayscale® Chainlink Trust': 'LINKFUND',
  'Grayscale® Decentraland Trust': 'MANAFUND',
  'Grayscale® Ethereum Trust': 'ETHE',
  'Grayscale® Ethereum Classic Trust': 'ETCG',
  'Grayscale® Filecoin Trust': 'FILFUND',
  'Grayscale® Horizen Trust': 'ZENFUND',
  'Grayscale® Litecoin Trust': 'LTCN',
  'Grayscale® Livepeer Trust': 'LPTFUND',
  'Grayscale® Stellar Lumens Trust': 'XLMFUND',
  'Grayscale® Zcash Trust': 'ZECFUND',
  'Grayscale® Digital Large Cap Fund': 'GDLC',
};
